<!doctype html>
<html lang="pl">

@include('shared.header')

<body>
    @include('shared.nav')


    @include('shared.footer')
</body>

</html>
