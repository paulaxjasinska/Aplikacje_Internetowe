<footer class="container-fluid bg-light fixed-bottom" style="border-top: 1px solid rgb(149, 149, 149);">
    <div class="row text-center pt-2">
        <p class="text-dark">&copy; Wycieczki górskie - 2023</p>
    </div>
</footer>
<script src="{{ asset('js/bootstrap.bundle.js') }}"></script>
