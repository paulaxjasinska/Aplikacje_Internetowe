<head>
    <link rel="icon" href="data:;base64,iVBORw0KGgo=">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Wycieczki górskie</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
</head>
